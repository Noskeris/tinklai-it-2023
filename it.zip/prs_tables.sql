-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 05, 2023 at 02:02 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prs`
--

-- --------------------------------------------------------

--
-- Table structure for table `naudotojai`
--

CREATE TABLE `naudotojai` (
  `Id` int(11) NOT NULL,
  `Vardas` varchar(20) NOT NULL,
  `Pavarde` varchar(20) NOT NULL,
  `Elpastas` varchar(30) NOT NULL,
  `Slaptazodis` varchar(100) NOT NULL,
  `RoleId` int(11) NOT NULL,
  `SpecialybeId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `naudotojai`
--

INSERT INTO `naudotojai` (`Id`, `Vardas`, `Pavarde`, `Elpastas`, `Slaptazodis`, `RoleId`, `SpecialybeId`) VALUES
(1, 'Nojus', 'Bronušas', 'noskerlt@gmail.com', '$2y$10$lJLzy4zLJIxcTUurKPXxg.4GeP/2cMbV/jQGSK/eV7FHkkLgIs2ie', 3, NULL),
(2, 'Saulius', 'Povilaitis', 'admin@prs.lt', '$2y$10$AnWBjHIMSU0cpVfAZHhkSO815jecEgVcWFme.8TImg/B5RCYFRq5y', 1, NULL),
(3, 'Moliūgas', 'Oranžinis', 'kjh@kjh.lt', '$2y$10$rZKMgsgTce93ytDLehAY7uyW6M86SFpE5Dz1kZjiY5ijHuIr9dIam', 2, 2),
(4, 'Paulius', 'Mieliauskas', 'doc@doc.lt', '$2y$10$fcUewuzp.XEgcExcL0Wk0Oska5C6QgbwWip7k0u4CR318Ch7Y9gwu', 2, 3),
(5, 'Karolis', 'Karalius', 'doc1@doc.lt', '$2y$10$m1vYuJ1TGqie7ltwPuG9YuYgo2xX3MSMkZWvJtHLo1KCF4NsjtQsa', 2, 2),
(6, 'Jonas', 'Vanagas', 'jonvan@prs.lt', '$2y$10$ncGrZlyarEhCLDrvzd4tHeemuvhbyoDuzumu.piHx9n1mNiQqLTby', 2, 3),
(7, 'zas', 'zaS', 'zas@gmail.com', '$2y$10$Kh.d/Cfdm5JN04tHKqT5iOiDXpgNMe3.1.CxSnbV5LryLWpPU1RiS', 3, NULL),
(8, 'Vardenis', 'Pavardenis', 'neuro@prs.lt', '$2y$10$1a7sCaqcOqqvPl4kWr1Q9uBdYO7bDmF2fQKuaIIfa/jtujKSJrqaG', 2, 4),
(9, 'Ugnius', 'Saule', 'ugnius@gmail.com', '$2y$10$STfMSBeGRYu8TJzlOfHTLexp.sX6lf8dOYl9wqGl5499uahJ5YBB.', 3, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `Id` int(11) NOT NULL,
  `Role` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`Id`, `Role`) VALUES
(1, 'Administratorius'),
(2, 'Gydytojas'),
(3, 'Pacientas');

-- --------------------------------------------------------

--
-- Table structure for table `specialybes`
--

CREATE TABLE `specialybes` (
  `Id` int(11) NOT NULL,
  `Pavadinimas` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `specialybes`
--

INSERT INTO `specialybes` (`Id`, `Pavadinimas`) VALUES
(2, 'Odontologas'),
(3, 'Dermatologas'),
(4, 'Neurologas'),
(5, 'Infektologas');

-- --------------------------------------------------------

--
-- Table structure for table `statusai`
--

CREATE TABLE `statusai` (
  `Id` int(11) NOT NULL,
  `Pavadinimas` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `statusai`
--

INSERT INTO `statusai` (`Id`, `Pavadinimas`) VALUES
(1, 'Rezervuota'),
(2, 'Atšaukta');

-- --------------------------------------------------------

--
-- Table structure for table `tvarkarasciai`
--

CREATE TABLE `tvarkarasciai` (
  `Id` int(11) NOT NULL,
  `DataNuo` datetime NOT NULL,
  `DataIki` datetime NOT NULL,
  `NaudotojoId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `tvarkarasciai`
--

INSERT INTO `tvarkarasciai` (`Id`, `DataNuo`, `DataIki`, `NaudotojoId`) VALUES
(7, '2023-01-07 13:00:00', '2023-01-07 14:00:00', 6),
(8, '2023-01-05 13:00:00', '2023-01-05 14:00:00', 6),
(9, '2023-01-05 12:00:00', '2023-01-05 13:00:00', 6),
(10, '2023-01-07 12:00:00', '2023-01-07 13:00:00', 6),
(11, '2023-01-05 14:00:00', '2023-01-05 15:00:00', 6),
(12, '2023-01-07 14:00:00', '2023-01-07 15:00:00', 6),
(13, '2023-12-15 12:00:00', '2023-12-15 12:45:00', 4),
(14, '2023-12-15 11:00:00', '2023-12-15 12:00:00', 4),
(15, '2023-11-08 15:30:00', '2023-11-08 17:20:00', 6),
(16, '2023-11-07 23:05:00', '2023-11-07 23:55:00', 6),
(17, '2023-11-07 23:55:00', '2023-11-07 23:59:00', 6),
(19, '2023-11-08 12:00:00', '2023-11-08 12:45:00', 6),
(20, '2023-11-09 08:00:00', '2023-11-09 09:00:00', 6),
(21, '2023-11-09 09:00:00', '2023-11-09 10:00:00', 6),
(22, '2023-11-09 10:00:00', '2023-11-09 11:00:00', 6),
(23, '2023-11-10 08:00:00', '2023-11-10 09:00:00', 6),
(24, '2023-11-10 09:00:00', '2023-11-10 10:00:00', 6),
(25, '2023-11-10 10:00:00', '2023-11-10 10:30:00', 6),
(26, '2023-11-08 15:00:00', '2023-11-08 16:00:00', 3),
(27, '2023-12-04 12:00:00', '2023-12-04 12:45:00', 4),
(28, '2023-12-04 12:00:00', '2023-12-04 12:15:00', 6),
(29, '2023-12-04 12:15:00', '2023-12-04 12:30:00', 6),
(30, '2023-12-04 12:30:00', '2023-12-04 12:45:00', 6),
(31, '2023-12-05 12:00:00', '2023-12-05 12:15:00', 6),
(32, '2023-12-05 12:15:00', '2023-12-05 12:30:00', 6),
(33, '2023-12-05 12:30:00', '2023-12-05 12:45:00', 6),
(34, '2023-12-05 12:45:00', '2023-12-05 12:50:00', 6),
(35, '2023-12-15 12:00:00', '2023-12-15 12:15:00', 3),
(36, '2023-12-15 12:15:00', '2023-12-15 12:30:00', 3),
(37, '2023-12-15 12:30:00', '2023-12-15 12:45:00', 3),
(38, '2023-12-15 12:45:00', '2023-12-15 13:00:00', 3),
(39, '2023-12-15 13:00:00', '2023-12-15 13:15:00', 3),
(40, '2023-12-15 13:15:00', '2023-12-15 13:30:00', 3),
(41, '2023-12-15 13:30:00', '2023-12-15 13:45:00', 3),
(42, '2023-12-15 13:45:00', '2023-12-15 14:00:00', 3),
(43, '2023-12-15 14:00:00', '2023-12-15 14:15:00', 3),
(44, '2023-12-15 14:15:00', '2023-12-15 14:30:00', 3),
(45, '2023-12-15 14:30:00', '2023-12-15 14:45:00', 3),
(46, '2023-12-15 14:45:00', '2023-12-15 15:00:00', 3),
(47, '2023-12-15 15:00:00', '2023-12-15 15:15:00', 3),
(48, '2023-12-15 15:15:00', '2023-12-15 15:30:00', 3),
(49, '2023-12-15 15:30:00', '2023-12-15 15:45:00', 3),
(50, '2023-12-15 15:45:00', '2023-12-15 16:00:00', 3);

-- --------------------------------------------------------

--
-- Table structure for table `vizitai`
--

CREATE TABLE `vizitai` (
  `Id` int(11) NOT NULL,
  `StatusasId` int(11) NOT NULL,
  `NaudotojoId` int(11) NOT NULL,
  `TvarkarascioId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `vizitai`
--

INSERT INTO `vizitai` (`Id`, `StatusasId`, `NaudotojoId`, `TvarkarascioId`) VALUES
(1, 1, 1, 10),
(2, 2, 1, 15),
(3, 2, 1, 15),
(4, 2, 1, 15),
(5, 2, 7, 14),
(6, 2, 7, 15),
(7, 2, 7, 14),
(8, 1, 1, 21),
(9, 1, 1, 15),
(10, 1, 1, 25),
(11, 1, 1, 22),
(12, 1, 1, 23),
(13, 2, 1, 14),
(14, 1, 1, 32);

-- --------------------------------------------------------

--
-- Table structure for table `zinutes`
--

CREATE TABLE `zinutes` (
  `Id` int(11) NOT NULL,
  `Tekstas` text NOT NULL,
  `Data` datetime NOT NULL,
  `VizitoId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `zinutes`
--

INSERT INTO `zinutes` (`Id`, `Tekstas`, `Data`, `VizitoId`) VALUES
(2, 'Labas, Nojau, tikiuosi jaučiatės po vizito gerai', '2023-12-04 20:05:02', 10),
(3, 'Gerkit vaistus', '2023-12-04 21:03:54', 10),
(4, 'Hi', '2023-12-04 21:07:28', 10),
(5, 'Labas', '2023-12-04 22:22:31', 11),
(6, 'Sportuok', '2023-12-04 23:13:54', 10),
(7, 'Gydykis, užteks prie ISP sėdėt', '2023-12-05 00:10:25', 13);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `naudotojai`
--
ALTER TABLE `naudotojai`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `Elpastas` (`Elpastas`),
  ADD KEY `fk_specialybe` (`SpecialybeId`),
  ADD KEY `fk_role` (`RoleId`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `specialybes`
--
ALTER TABLE `specialybes`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `statusai`
--
ALTER TABLE `statusai`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tvarkarasciai`
--
ALTER TABLE `tvarkarasciai`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `fk_naudotojas` (`NaudotojoId`);

--
-- Indexes for table `vizitai`
--
ALTER TABLE `vizitai`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `fk_statusas` (`StatusasId`),
  ADD KEY `fk_naudotojas_v` (`NaudotojoId`),
  ADD KEY `fk_tvarkarastis` (`TvarkarascioId`);

--
-- Indexes for table `zinutes`
--
ALTER TABLE `zinutes`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `fk_vizitas` (`VizitoId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `naudotojai`
--
ALTER TABLE `naudotojai`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `specialybes`
--
ALTER TABLE `specialybes`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `statusai`
--
ALTER TABLE `statusai`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tvarkarasciai`
--
ALTER TABLE `tvarkarasciai`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `vizitai`
--
ALTER TABLE `vizitai`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `zinutes`
--
ALTER TABLE `zinutes`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `naudotojai`
--
ALTER TABLE `naudotojai`
  ADD CONSTRAINT `fk_role` FOREIGN KEY (`RoleId`) REFERENCES `roles` (`Id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_specialybe` FOREIGN KEY (`SpecialybeId`) REFERENCES `specialybes` (`Id`) ON UPDATE CASCADE;

--
-- Constraints for table `tvarkarasciai`
--
ALTER TABLE `tvarkarasciai`
  ADD CONSTRAINT `fk_naudotojas` FOREIGN KEY (`NaudotojoId`) REFERENCES `naudotojai` (`Id`) ON UPDATE CASCADE;

--
-- Constraints for table `vizitai`
--
ALTER TABLE `vizitai`
  ADD CONSTRAINT `fk_naudotojas_v` FOREIGN KEY (`NaudotojoId`) REFERENCES `naudotojai` (`Id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_statusas` FOREIGN KEY (`StatusasId`) REFERENCES `statusai` (`Id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_tvarkarastis` FOREIGN KEY (`TvarkarascioId`) REFERENCES `tvarkarasciai` (`Id`) ON UPDATE CASCADE;

--
-- Constraints for table `zinutes`
--
ALTER TABLE `zinutes`
  ADD CONSTRAINT `fk_vizitas` FOREIGN KEY (`VizitoId`) REFERENCES `vizitai` (`Id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
