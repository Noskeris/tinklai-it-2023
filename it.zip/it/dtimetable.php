<?php
global $conn;
include_once 'sidenav.php';
if (!isset($_SESSION['role'])) {
    header("Location: handle/logout.php");
    exit;
}
if ($_SESSION['role'] != 2) {
    header("Location: home.php");
    exit;
}

$id = $_SESSION["userid"];

require_once 'handle/config.php';
require_once 'handle/functions.php';


$doctor = getDoctor($conn, $id);

$sql = "SELECT
    tm.Id,
    DATE(DataNuo) AS Data,
    CONCAT(DATE_FORMAT(DataNuo, '%H:%i'), '-', DATE_FORMAT(DataIki, '%H:%i')) AS Laikas,
    IF(NOW() BETWEEN DataNuo AND DataIki, 1, 0) AS ArDabar,
    c.VizituSkaicius,
    COALESCE(v.Pacientas, '-') AS Pacientas
FROM tvarkarasciai tm
LEFT JOIN (
    SELECT
        NaudotojoId,
        DATE(DataNuo) AS Data,
        COUNT(*) AS VizituSkaicius
    FROM tvarkarasciai
    GROUP BY NaudotojoId, DATE(DataNuo)
) c ON tm.NaudotojoId = c.NaudotojoId AND DATE(tm.DataNuo) = c.Data
LEFT JOIN (
    SELECT
        v.TvarkarascioId,
        CONCAT(n.Vardas, ' ', n.Pavarde) AS Pacientas
    FROM vizitai v
    JOIN naudotojai n ON v.NaudotojoId = n.Id
    WHERE StatusasId = 1
) v ON v.TvarkarascioId = tm.Id
WHERE tm.NaudotojoId = ?
ORDER BY DATE(DataNuo) DESC, TIME(DataNuo) DESC;";

$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt, $sql)) {
    return false;
}

mysqli_stmt_bind_param($stmt, "s", $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

?>

<html lang="lt">
<head>
    <style>
        .clickable-row:hover {
            background-color: #f2f2f2;
            cursor: pointer;
        }

        .clicked-row {
            background-color: #e0e0e0;
        }
    </style>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


</head>

<body>
<div class="content">
    <h1 class="text-success d-flex justify-content-center">Mano tvarkaraštis</h1>
    <p class="d-flex justify-content-center">Čia galite matyti savo tvarkaraštį bei užsiregistravusius
        pacientus vizitui. Paspaudus ant vizito laiko, galima išsiųsti žinutę pacientui</p>

    <?php
    if (isset($_GET["error"])) {
        echo "<b class='text-danger'>";
        if ($_GET["error"] == "stmtfailed") {
            echo "Klaida: bandykite dar kartą";
        }
        if ($_GET["error"] == "empty") {
            echo "Klaida: Nevisi laukai yra užpildyti";
        }

        echo "</b>";

        if ($_GET["error"] == "none") {
            echo "<b class='text-success'>Žinutė sėkmingai išsiųsta</b>";
        }
    }
    ?>

    <div class="modal fade" id="writeMessageModal" tabindex="-1" aria-labelledby="writeMessageModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="writeMessageModalLabel">Rašyti žinutę pacientui</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <form action="handle/writeMessage.php" method="POST" onsubmit="return validateForm()">
                    <div class="modal-body">
                        <div class="form-group">
                            <input type="hidden" id="idInput" name="id">
                        </div>
                        <div class="form-group">
                            <label for="messageInput">Žinutė</label>
                            <textarea class="form-control" id="messageInput" name="message" rows="5" placeholder="Įrašykite žinutę..."></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Atšaukti</button>
                        <button type="submit" name="sendmessage" class="btn btn-success">Siųsti</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php

    echo "<b><p class='d-flex justify-content-center'>" . "Gyd. " .
        $doctor['Vardas'] . " " . $doctor['Pavarde'] .
        " - " . $doctor['Specialybe'] .
        "</p></b>";

    ?>

    <table class="table">
        <thead>
        <tr>
            <th style='text-align: center;'>Data</th>
            <th style='text-align: center;'>Laikas</th>
            <th style='text-align: center;'>Pacientas</th>
        </tr>
        </thead>
        <tbody>
        <?php
        if (mysqli_num_rows($result) === 0) {
            echo "<tr><td colspan='3' style='text-align: center;'>Šiuo metu gydytojas neturi sudaryto tvarkaraščio</td></tr>";
        } else {
            $day = "";
            while ($row = mysqli_fetch_assoc($result)) {
                $backgroundcolor = '';
                if ($row["ArDabar"]) {
                    $backgroundcolor = 'font-weight: bold; color: green;';
                }
                if ($day !== $row["Data"]) {
                    $day = $row["Data"];
                    echo "<td rowspan='" . $row["VizituSkaicius"] . "' style='text-align: center;'>" . $row['Data'] . "</td>";
                }
                echo "<td style='text-align: center;" . $backgroundcolor . "'>" . $row['Laikas'] . "</td>";
                echo "<td style='" . $backgroundcolor . "'>" . $row['Pacientas'];

                if ($row['Pacientas'] != '-') {


                    echo "<button type='button' 
                    class='btn btn-success clickable-cell' 
                    style='margin-left: 20px' 
                    data-id='". $row['Id'] ."'
                    data-bs-toggle='modal' 
                    data-bs-target='#writeMessageModal'>
                    
                        Rašyti žinutę
                    </button>";
                }

                echo "</td></tr>";
            }
        }
        ?>
        </tbody>
    </table>
</div>



</body>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const cells = document.querySelectorAll(".clickable-cell");

        cells.forEach(function(cell) {
            cell.addEventListener("click", function () {
                const id = cell.getAttribute("data-id");
                openModalWithId(id);
            });
        });

        function openModalWithId(id) {
            const modalForm = document.querySelector("#writeMessageModal form");
            const idInput = modalForm.querySelector("[name='id']");
            console.log(id);
            idInput.value = id;
        }
    });
</script>

</html>