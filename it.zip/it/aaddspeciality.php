<?php
global $conn;
include_once 'sidenav.php';
if (!isset($_SESSION['role'])) {
    header("Location: handle/logout.php");
    exit;
}
if ($_SESSION['role'] != 1) {
    header("Location: home.php");
    exit;
}

require_once("handle/config.php");
$sql = "select Pavadinimas from specialybes";
$result = mysqli_query($conn, $sql);

?>

<div class="content">
    <form action="handle/handleaddspeciality.php" method="POST">
        <h1 class="text-success d-flex justify-content-center">Specialybės pridėjimas</h1>

        <?php
        $acc = false;
        echo "<b class=\"text-danger\">";
        if (isset($_GET["error"])) {
            if ($_GET["error"] == "stmtfailed") {
                echo "Klaida, bandykite dar kartą.";
            }
            if ($_GET["error"] == "empty") {
                echo "Nevisi laukai yra užpildyti.";
            }
            if ($_GET["error"] == "specialityexists") {
                echo "Tokia specialybė jau egzistuoja";
            }
            if ($_GET["error"] == "none") {
                $acc = true;
            }
        }
        echo "</b>";
        if ($acc === true) {
            echo "<b class=\"text-success\">Specialybė sėkmingai pridėta</b>";
        }
        ?>

        <div class="form-group">

            <label>Naujos specialybės pavadinimas:</label>
            <input class="form-control mb-3" name="name" placeholder="Pavadinimas" type="text" required
                   oninvalid="this.setCustomValidity('Įveskite pavadinimą')" oninput="this.setCustomValidity('')"/>

            <button type="submit" name="addspeciality" class="btn btn-success btn-block">Pridėti specialybę</button>
        </div>
    </form>

    <table class="table">
        <thead>
        <tr>
            <th>Užregistruotos specialybės</th>
        </tr>
        </thead>
        <tbody>
        <?php
        if (mysqli_num_rows($result) === 0) {
            echo "<tr><td colspan='7' style='text-align: center;'>Šiuo metu nėra užregistruotų specialybių</td></tr>";
        } else {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<td>" . $row['Pavadinimas'] . "</td>";
                echo "</tr>";
            }
        }
        ?>
        </tbody>
    </table>
</div>