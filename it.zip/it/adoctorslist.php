<?php
global $conn;
include_once 'sidenav.php';
if (!isset($_SESSION['role'])) {
    header("Location: handle/logout.php");
    exit;
}
if ($_SESSION['role'] != 1) {
    header("Location: home.php");
    exit;
}
require_once("handle/config.php");
$sql = "SELECT
    n.Id,
    Vardas,
    Pavarde,
    s.Pavadinimas as Specialybe
FROM naudotojai n
LEFT JOIN specialybes s ON n.SpecialybeId = s.Id
WHERE RoleId = 2
ORDER BY s.Pavadinimas, Vardas, Pavarde";
$result = mysqli_query($conn, $sql);

?>

<div class="content">
    <h1 class="text-success d-flex justify-content-center">Gydytojų sąrašas</h1>
    <p class="d-flex justify-content-center">Visi sistemoje užregistruoti gydytojai. Norėdami pridėti naują laiką į
        gydytojo tvarkaraštį, pasirinkite gydytoją iš sąrašo</p>

    <table class="table">
        <thead>
        <tr>
            <th>Gydytojo vardas ir pavardė</th>
            <th>Specialybė</th>
        </tr>
        </thead>
        <tbody>
        <?php
        if (mysqli_num_rows($result) === 0) {
            echo "<tr><td colspan='7' style='text-align: center;'>Šiuo metu nėra užregistruotų gydytojų</td></tr>";
        } else {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr class='clickable-row' data-href='atimetable.php?id=" . $row['Id'] . "'>";
                echo "<td>" . $row['Vardas'] . " " . $row['Pavarde'] . "</td>";
                echo "<td>" . $row['Specialybe'] . "</td>";
                echo "</tr>";
            }
        }
        ?>
        </tbody>
    </table>
</div>

<style>
    .clickable-row:hover {
        background-color: #f2f2f2;
        cursor: pointer;
    }
    .clicked-row {
        background-color: #e0e0e0;
    }
</style>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const rows = document.querySelectorAll(".clickable-row");

        rows.forEach((row) => {
            row.addEventListener("click", function () {
                window.location.href = row.getAttribute("data-href");

                rows.forEach((r) => {
                    r.classList.remove("clicked-row");
                });

                row.classList.add("clicked-row");
            });
        });
    });
</script>
