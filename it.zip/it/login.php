<?php
include_once 'sidenav.php';
if (isset($_SESSION['role'])) {
    header("Location: home.php");
    exit;
}
?>
<div class="content">
    <form action="handle/handlelogin.php" method="POST" class="login">
        <h1 class="mx-auto text-success"><b>Prisijungimas</b></h1>
        <?php
        echo "<b class='text-danger'>";
        if (isset($_GET["error"])) {
            if ($_GET["error"] == "stmtfailed") {
                echo "Klaida, bandykite dar kartą";
            }
            if ($_GET["error"] == "empty") {
                echo "Nevisi laukai yra užpildyti";
            }
            if ($_GET["error"] == "wronglogin") {
                echo "Neteisingas slaptažodis arba el. pašto adresas";
            }
        }
        echo "</b>";
        ?>
        <div class="form-group">
            <label>El. pašto adresas:</label>
            <input class="form-control mb-3" name="email" required placeholder="El. pašto adresas" type="text"
                   oninvalid="this.setCustomValidity('Įveskite el. pašto adresą')"
                   oninput="this.setCustomValidity('')"/>

            <label>Slaptažodis:</label>
            <input class="form-control mb-3" name="pass" required placeholder="Slaptažodis" type="password"
                   oninvalid="this.setCustomValidity('Įveskite slaptažodį')" oninput="this.setCustomValidity('')"/>

            <button type="submit" name="login" class="btn btn-success btn-block">Prisijungti</button>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item rounded text-secondary" href="register.php">Neturite paskyros? Susikurkite čia</a>
        </div>
    </form>
</div>