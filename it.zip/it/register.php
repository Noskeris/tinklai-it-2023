<?php
include_once 'sidenav.php';
if (isset($_SESSION['role'])) {
    header("Location: home.php");
    exit;
}
?>

<div class="content">
    <form action="handle/handleregister.php" method="POST">
        <h1 class="mx-auto text-success"><b>Registracija</b></h1>

        <?php
        $acc = false;
        echo "<b class=\"text-danger\">";
        if (isset($_GET["error"])) {
            if ($_GET["error"] == "stmtfailed") {
                echo "Klaida, bandykite dar kartą.";
            }
            if ($_GET["error"] == "empty") {
                echo "Nevisi laukai yra užpildyti.";
            }
            if ($_GET["error"] == "invalidpassword") {
                echo "Slaptažodis turi būti bent 8 simbolių ir sudarytas iš skaitmenų bei raidžių.";
            }
            if ($_GET["error"] == "invalidemail") {
                echo "Neteisingas el. pašto adresas";
            }
            if ($_GET["error"] == "passwordsdoesntmatch") {
                echo "Slapažodžiai nesutampa";
            }
            if ($_GET["error"] == "userexists") {
                echo "Toks el. paštas jau egzistuoja";
            }
            if ($_GET["error"] == "none") {
                $acc = true;
            }
        }
        echo "</b>";
        if ($acc === true) {
            echo "<b class=\"text-success\">Paskyra sėkmingai sukurta</b>";
        }
        ?>

        <div class="form-group">

            <label>Vardas:</label>
            <input class="form-control" name="name" placeholder="Vardas" type="text" required
                   oninvalid="this.setCustomValidity('Įveskite vardą')" oninput="this.setCustomValidity('')"/>

            <label>Pavardė:</label>
            <input class="form-control" name="surname" placeholder="Pavardė" type="text" required
                   oninvalid="this.setCustomValidity('Įveskite Pavardę')" oninput="this.setCustomValidity('')"/>

            <label>El. paštas:</label>
            <input class="form-control mb-3" name="email" placeholder="El. pašto adresas" type="email" required
                   oninvalid="this.setCustomValidity('Įveskite el. pašto adresą')"
                   oninput="this.setCustomValidity('')"/>

            <label>Slaptažodis:</label>
            <small id="passHelp" class="form-text text-muted">
                Slaptažodis turi būti bent 8 simbolių ir sudarytas iš skaitmenų bei raidžių.
            </small>

            <input class="form-control mb-3" aria-describedby="passHelp" name="pass" placeholder="Slaptažodis"
                   type="password" required oninvalid="this.setCustomValidity('Įveskite slaptažodį')"
                   oninput="this.setCustomValidity('')"/>
            <label>Įrašykite dar kartą slaptažodį:</label>
            <input class="form-control mb-3" name="passRepeat" placeholder="Slaptažodis" type="password" required
                   oninvalid="this.setCustomValidity('Įveskite slaptažodį')" oninput="this.setCustomValidity('')"/>

            <button type="submit" name="register" class="btn btn-success btn-block">Registruotis</button>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item rounded text-secondary" href="login.php">Jau turite paskyrą? Prisijunkite čia</a>
        </div>
    </form>
</div>