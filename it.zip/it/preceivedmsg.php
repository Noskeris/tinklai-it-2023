<?php
global $conn;
include_once 'sidenav.php';
if (!isset($_SESSION['role'])) {
    header("Location: handle/logout.php");
    exit;
}
if ($_SESSION['role'] != 3) {
    header("Location: home.php");
    exit;
}

$id = $_SESSION["userid"];

require_once("handle/config.php");

$sql = "select
    concat(n.Vardas, ' ', n.Pavarde) as Gydytojas,
    s.Pavadinimas as Specialybe,
    CONCAT(DATE(t.DataNuo), ' ', DATE_FORMAT(t.DataNuo, '%H:%i'), '-', DATE_FORMAT(t.DataIki, '%H:%i')) AS VizitoData,
    z.Tekstas,
    z.Data as SiuntimoData
from zinutes z
join vizitai v on z.VizitoId = v.Id
join tvarkarasciai t on v.TvarkarascioId = t.Id
join naudotojai n on t.NaudotojoId = n.Id
join specialybes s on n.SpecialybeId = s.Id
where v.NaudotojoId = ?
order by z.Data desc";

$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt, $sql)) {
    return false;
}

mysqli_stmt_bind_param($stmt, "s", $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
?>

<div class="content ">
    <h1 class="text-success d-flex justify-content-center">Gautos žinutės</h1>
    <p class="d-flex justify-content-center">Čia rasite jums gydytojų paliktas žinutes</p>

    <table class="table">
        <thead>
        <tr>
            <th style='text-align: center;'>Data</th>
            <th style='text-align: center;'>Gydytojas</th>
            <th style='text-align: center;'>Specialybė</th>
            <th style='text-align: center;'>Vizito laikas</th>
            <th style='text-align: center;'>Žinutė</th>
        </tr>
        </thead>
        <tbody>
        <?php
        if (mysqli_num_rows($result) === 0) {
            echo "<tr><td colspan='5' style='text-align: center;'>Šiuo metu neturite jokių gautų žinučių</td></tr>";
        } else {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<td>" . $row['SiuntimoData'] . "</td>";
                echo "<td>" . $row['Gydytojas'] . "</td>";
                echo "<td>" . $row['Specialybe'] . "</td>";
                echo "<td>" . $row['VizitoData'] . "</td>";
                echo "<td>" . $row['Tekstas'] . "</td>";
                echo "</tr>";
            }
        }
        ?>
        </tbody>
    </table>
</div>