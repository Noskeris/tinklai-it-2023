<?php
session_start();
?>

<!DOCTYPE html>
<html lang="lt">

<head>
    <meta http-equiv="X-UA-Compatible" charset="UTF-8" content="IE=9; text/html">
    <title>Pacientų registracijos sistema</title>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
</head>

<body class="bg-light d-flex justify-content-center">
<?php if (isset($_SESSION['username'])) : ?>
    <div class="sidenav bg-success d-flex flex-column" style="height: 100vh; display: flex;">
        <a href="home.php" class="text-light" style="margin-bottom: 50px"><b>PACIENTŲ REGISTRACIJOS SISTEMA</b></a>
        <?php
        $user_roles_by_id = array(
            "1" => "Administratorius",
            "2" => "Gydytojas",
            "3" => "Pacientas"
        );
        if (isset($_SESSION['role']) && isset($_SESSION['vardas']) && isset($_SESSION['pavarde'])) {
            echo "<div style='margin-bottom: 50px'><b>Vardas:</b> " . $_SESSION['vardas']."<br>";
            echo "<b>Pavardė:</b> " . $_SESSION['pavarde']."<br>";
            echo "<b>Rolė:</b> " . $user_roles_by_id[$_SESSION['role']]."</div>";
        }
        echo "<a href='home.php' class='btn btn-light shadow bg-white rounded' style='margin-bottom: 50px'>Pagrindinis puslapis</a>";
        if (isset($_SESSION['role'])) {
            if ($_SESSION['role'] == 3) {
                echo "<a href='pvisithistory.php' class='btn btn-light shadow bg-white rounded'>Mano vizitų istorija</a>";
                echo "<a href='preceivedmsg.php' class='btn btn-light shadow bg-white rounded'>Gautos žinutės</a>";
                echo "<a href='pdoctorslist.php' class='btn btn-light shadow bg-white rounded'>Registracija pas gydytojus</a>";
            }
            if ($_SESSION['role'] == 2) {
                echo "<a href='dtimetable.php' class='btn btn-light shadow bg-white rounded'>Mano tvarkaraštis</a>";
            }
            if ($_SESSION['role'] == 1) {
                echo "<a href='aaddspeciality.php' class='btn btn-light shadow bg-white rounded'>Pridėti specialybę</a>";
                echo "<a href='aregisterdoctor.php' class='btn btn-light shadow bg-white rounded'>Užregistruoti gydytoją</a>";
                echo "<a href='adoctorslist.php' class='btn btn-light shadow bg-white rounded'>Gydytojų sąrašas</a>";
            }

            echo "<div class='flex-grow-1'></div>";
            echo "<a href='handle/logout.php' class='btn btn-danger shadow rounded'>Atsijungti</a>";
        }
        ?>
    </div>
<?php endif; ?>

<style>
    .sidenav {
        width: 250px;
        position: fixed;
        top: 0;
        left: 0;
        height: 100%;
        background-color: #34495E;
        color: #fff;
        padding: 20px;
    }

    .sidenav a {
        display: block;
        margin-bottom: 10px;
        text-decoration: none;
    }

    <?php if (isset($_SESSION['username'])) : ?>.content {
        margin-left: 250px;
        padding: 20px;
    }

    <?php endif; ?>
</style>
</body>

</html>