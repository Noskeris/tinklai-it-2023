<?php
global $conn;
include_once 'sidenav.php';
if (!isset($_SESSION['role'])) {
    header("Location: handle/logout.php");
    exit;
}
if ($_SESSION['role'] != 3) {
    header("Location: home.php");
    exit;
}
require_once("handle/config.php");
$sql = "select
    n.Id,
    Vardas,
    Pavarde,
    s.Pavadinimas as Specialybe
from naudotojai n
join specialybes s on n.SpecialybeId = s.Id
where RoleId = 2
order by s.Pavadinimas, Vardas, Pavarde";
$result = mysqli_query($conn, $sql);

?>

<div class="content ">
    <h1 class="text-success d-flex justify-content-center">Gydytojų sąrašas</h1>
    <p class="d-flex justify-content-center">Čia rasite visus mūsų gydytojus. Norėdami užsirašyti pas vieną iš jų,
        paspauskite ant norimo gydytojo ir iš gydytojo tvarkaraščio pasirinkite norimą laiką</p>


    <table class="table">
        <thead>
        <tr>
            <th>Gydytojo vardas ir pavardė</th>
            <th>Specialybė</th>
        </tr>
        </thead>
        <tbody>
        <?php
        if (mysqli_num_rows($result) === 0) {
            echo "<tr><td colspan='7' style='text-align: center;'>Šiuo metu nėra užregistruotų gydytojų</td></tr>";
        } else {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr class='clickable-row' data-href=ptimetable.php?id=" . $row['Id'] . ">";
                echo "<td>" . $row['Vardas'] . " " . $row['Pavarde'] . "</td>";
                echo "<td>" . $row['Specialybe'] . "</td>";
                echo "</tr>";
            }
        }
        ?>
        </tbody>
    </table>
</div>

<style>
    .clickable-row:hover {
        background-color: #f2f2f2;
        cursor: pointer;
    }
    .clicked-row {
        background-color: #e0e0e0;
    }
</style>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const rows = document.querySelectorAll(".clickable-row");

        rows.forEach((row) => {
            row.addEventListener("click", function () {
                window.location.href = row.getAttribute("data-href");

                rows.forEach((r) => {
                    r.classList.remove("clicked-row");
                });

                row.classList.add("clicked-row");
            });
        });
    });
</script>
