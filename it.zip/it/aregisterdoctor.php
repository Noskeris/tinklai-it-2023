<?php
global $conn;
include_once 'sidenav.php';
if (!isset($_SESSION['role'])) {
    header("Location: handle/logout.php");
    exit;
}
if ($_SESSION['role'] != 1) {
    header("Location: home.php");
    exit;
}

require_once("handle/config.php");
$sql = "SELECT 
    Id,
    Pavadinimas
FROM specialybes";
$result = mysqli_query($conn, $sql);
?>

<div class="content">
    <form action="handle/handledoctorregister.php" method="POST">
        <h1 class="text-success d-flex justify-content-center">Gydytojo registracija</h1>

        <?php
        $acc = false;
        echo "<b class=\"text-danger\">";
        if (isset($_GET["error"])) {
            if ($_GET["error"] == "stmtfailed") {
                echo "Klaida, bandykite dar kartą.";
            }
            if ($_GET["error"] == "empty") {
                echo "Nevisi laukai yra užpildyti.";
            }
            if ($_GET["error"] == "invalidpassword") {
                echo "Slaptažodis turi būti bent 8 simbolių ir sudarytas iš skaitmenų bei raidžių.";
            }
            if ($_GET["error"] == "invalidemail") {
                echo "Neteisingas el. pašto adresas";
            }
            if ($_GET["error"] == "invalidspeciality") {
                echo "Tokia specialybė neegzistuoja";
            }
            if ($_GET["error"] == "passwordsdoesntmatch") {
                echo "Slapažodžiai nesutampa";
            }
            if ($_GET["error"] == "userexists") {
                echo "Toks el. paštas jau egzistuoja";
            }
            if ($_GET["error"] == "none") {
                $acc = true;
            }
        }
        echo "</b>";
        if ($acc === true) {
            echo "<b class=\"text-success\">Paskyra sėkmingai sukurta</b>";
        }
        ?>

        <div class="form-group">

            <label>Gydytojo vardas:</label>
            <input class="form-control" name="name" placeholder="Vardas" type="text" required
                   oninvalid="this.setCustomValidity('Įveskite vardą')" oninput="this.setCustomValidity('')"/>

            <label>Gydytojo pavardė:</label>
            <input class="form-control" name="surname" placeholder="Pavardė" type="text" required
                   oninvalid="this.setCustomValidity('Įveskite Pavardę')" oninput="this.setCustomValidity('')"/>

            <label>Specialybė:</label>
            <select class="form-control" name="speciality" required onchange="validateSpecialty(this)"
                    oninvalid="this.setCustomValidity('Pasirinkti specialybę iš sąrašo')">
                <option value="">- Pasirinkti specialybę -</option>
                <?php
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<option value='" . $row['Id'] . "'>" . $row['Pavadinimas'] . "</option>";
                }
                ?>
            </select>

            <label>Gydytojo el. pašto adresas:</label>
            <input class="form-control mb-3" name="email" placeholder="El. pašto adresas" type="email" required
                   oninvalid="this.setCustomValidity('Įveskite el. pašto adresą')"
                   oninput="this.setCustomValidity('')"/>

            <label>Slaptažodis:</label>
            <small id="passHelp" class="form-text text-muted">
                Slaptažodis turi būti bent 8 simbolių ir sudarytas iš skaitmenų bei raidžių.
            </small>

            <input class="form-control mb-3" aria-describedby="passHelp" name="pass" placeholder="Slaptažodis"
                   type="password" required oninvalid="this.setCustomValidity('Įveskite slaptažodį')"
                   oninput="this.setCustomValidity('')"/>
            <label>Įrašykite dar kartą slaptažodį:</label>
            <input class="form-control mb-3" name="passRepeat" placeholder="Slaptažodis" type="password" required
                   oninvalid="this.setCustomValidity('Įveskite slaptažodį')" oninput="this.setCustomValidity('')"/>

            <button type="submit" name="registerdoctor" class="btn btn-success btn-block">Registruoti gydytoją</button>
        </div>
    </form>
</div>

<script>
    function validateSpecialty(selectElement) {
        if (selectElement.value === "") {
            selectElement.setCustomValidity("Pasirinkite specialybę.");
        } else {
            selectElement.setCustomValidity("");
        }
    }
</script>

