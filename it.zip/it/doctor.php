<?php
if (!isset($_SESSION['role'])) {
    header("Location: handle/logout.php");
    exit;
}
if ($_SESSION['role'] != 2) {
    header("Location: home.php");
    exit;
}
?>

<style>
    .paragraph {
        margin-bottom: 20px;
    }
</style>

<h1 class="text-success d-flex justify-content-center">Pagrindinis puslapis</h1>
<h4>Sveiki, gydytojau!</h4>

<p class="text-dark" style="text-align: center;">
    Gydytojo panelėje galite galite matyti savo tvarkaraštį bei užsiregistravusius
    pacientus vizitui. Paspaudus ant vizito laiko, galima išsiųsti žinutę pacientui.
</p>