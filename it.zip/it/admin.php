<?php
if (!isset($_SESSION['role'])) {
    header("Location: handle/logout.php");
    exit;
}
if ($_SESSION['role'] != 1) {
    header("Location: home.php");
    exit;
}
?>

<style>
    .paragraph {
        margin-bottom: 20px;
    }
</style>

<h1 class="text-success d-flex justify-content-center">Pagrindinis puslapis</h1>
<h4>Sveiki, administratoriau!</h4>

<p class="text-dark" style="text-align: center;">
    Administratoriaus panelėje galite pridėti naujas specialybes, užregistruoti naujus gydytojus bei sudaryti jiems
    darbo laiko tvarkaraščius.
</p>