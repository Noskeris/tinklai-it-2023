<?php
if (!isset($_SESSION['role'])) {
    header("Location: handle/logout.php");
    exit;
}
if ($_SESSION['role'] != 3) {
    header("Location: home.php");
    exit;
}
?>

<style>
    .paragraph {
        margin-bottom: 20px;
    }
</style>

<h1 class="text-success d-flex justify-content-center">Pagrindinis puslapis</h1>
<div style="text-align: justify;">
    <b>Sistemos idėja</b>
    <i>
        <div class="paragraph">
            Pacientų registracijos sistema yra moderni ir efektyvi priemonė, leidžianti lengvai ir patogiai organizuoti
            pacientų priėmimą ir registraciją sveikatos įstaigose. Ši sistema turi daugybę naudingų funkcijų, kurios
            suteikia pacientams ir medicinos personalui geriausias sąlygas.
        </div>
        <div class="paragraph">
            Viena iš svarbiausių šios sistemos privalumų yra galimybė užsiregistruoti pas gydytoją internetu. Tai
            sutaupo pacientams laiką ir užtikrina patogumą, nes nereikia ilgai laukti eilėse ar skambinti į
            registratūrą. Registracijos sistema taip pat leidžia pacientams peržiūrėti savo buvusių ir ateinančių
            apsilankymų datas ir gauti svarbią informaciją iš gydytojų.
        </div>
        <div class="paragraph">
            Medicinos personalui ši sistema suteikia galimybę lengvai tvarkyti pacientų registracijas. Tai pagerina
            darbo efektyvumą ir padeda sutaupyti laiko, kuris gali būti skirtas pacientų aptarnavimui.
        </div>
        <div class="paragraph">
            Be to, pacientų registracijos sistema prisideda prie duomenų saugumo. Visi pacientų duomenys saugomi
            saugioje elektroninėje aplinkoje, o prieiga prie jų yra ribojama, užtikrinant konfidencialumą ir privatumą.
        </div>
        <div class="paragraph">
            Pacientų registracijos sistema tapo neįkainojamu sveikatos priežiūros įstaigų įrankiu, palengvinančiu tiek
            pacientų, tiek medicinos personalo gyvenimą. Tai yra žingsnis į priekį link efektyvesnės, patogesnės ir
            saugesnės sveikatos priežiūros sistemos ateityje.
        </div>
    </i>
</div>
<h3 class="text-dark" style="text-align: center;">
    Rinktis gydytojus bei pas juos registruotis, tvarkyti savo
    vizitus galite paspaudę mygtukus esančius navigacijoje
</h3>