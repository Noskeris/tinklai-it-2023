<?php
global $conn;
session_start();

if (!isset($_SESSION['role'])) {
    header("Location: logout.php");
    exit;
}
if ($_SESSION['role'] != 1) {
    header("Location: ../home.php");
    exit;
}
require_once 'config.php';
require_once 'functions.php';
if (isset($_POST["addspeciality"])) {
    $name = $_POST["name"];
    require_once 'config.php';
    require_once 'functions.php';

    if (emptyInput($name)) {
        header("location: ../aaddspeciality.php?error=empty");
        exit();
    }

    addSpeciality($conn, $name);
    exit();
} else {
    header("location: ../aaddspeciality.php");
}

