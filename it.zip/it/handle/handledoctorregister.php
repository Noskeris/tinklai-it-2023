<?php
global $conn;
session_start();
if (!isset($_SESSION['role'])) {
    header("Location: logout.php");
    exit;
}
if ($_SESSION['role'] != 1) {
    header("Location: ../home.php");
    exit;
}
require_once 'config.php';
require_once 'functions.php';
if (isset($_POST["registerdoctor"])) {
    $name = $_POST["name"];
    $surname = $_POST["surname"];
    $email = $_POST["email"];
    $pass = $_POST["pass"];
    $passRepeat = $_POST["passRepeat"];
    $spciality = $_POST["speciality"];

    if (emptyInputsRegister($name, $surname, $email, $pass, $passRepeat) !== false) {
        header("location: ../aregisterdoctor.php?error=empty");
        exit();
    }
    if (invalidemail($email) !== false) {
        header("location: ../aregisterdoctor.php?error=invalidemail");
        exit();
    }
    if (passMatch($pass, $passRepeat) !== false) {
        header("location: ../aregisterdoctor.php?error=passwordsdoesntmatch");
        exit();
    }
    if (invalidPass($pass) !== false) {
        header("location: ../aregisterdoctor.php?error=invalidpassword");
        exit();
    }
    createAccount($conn, $name, $surname, $email, $pass, 2, $spciality);
    exit();
} else {
    header("location: ../aregisterdoctor.php");
}

