<?php
global $conn;
session_start();
if (!isset($_SESSION['role'])) {
    header("Location: logout.php");
    exit;
}
if ($_SESSION['role'] != 3) {
    header("Location: ../home.php");
    exit;
}

require_once 'config.php';
require_once 'functions.php';

if (isset($_POST["cancelVisit"])) {
    $id = $_POST["id"];

    if (emptyInput($id)) {
        header("location: ../pvisithistory.php");
        exit();
    }

    cancelVisit($conn, $id);
    exit();
} else {
    header("location: ../pvisithistory.php");
}

