<?php
global $conn;
session_start();
if (!isset($_SESSION['role'])) {
    header("Location: logout.php");
    exit;
}
if ($_SESSION['role'] != 1) {
    header("Location: ../home.php");
    exit;
}
require_once 'config.php';
require_once 'functions.php';
$id = $_POST["id"];
if (isset($_POST["addtime"])) {
    $diena = $_POST["diena"];
    $nuo = $_POST["nuo"];
    $iki = $_POST["iki"];
    $intervalas = $_POST["intervalas"];

    if (emptyInput($diena) || emptyInput($nuo) || emptyInput($iki) || emptyInput($intervalas)) {
        header("location: ../atimetable.php?id=" . $id . "&error=empty");
        exit();
    }

    if (!isValidDateAndTime($nuo, $iki, $diena, $intervalas)) {
        header("location: ../atimetable.php?id=" . $id . "&error=baddateortime");
        exit();
    }

    addTime($conn, $id, $nuo, $iki, $diena, $intervalas);
    exit();
} else {
    header("location: ../atimetable.php?id=" . $id);
}

