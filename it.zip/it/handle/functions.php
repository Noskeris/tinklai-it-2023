<?php
require_once("config.php");

function emptyInputsRegister($name, $surname, $email, $pass, $passRepeat)
{
    if (empty($name) || empty($surname) || empty($email) || empty($pass) || empty($passRepeat)) {
        return true;
    }
    return false;
}

function emptyInputsLogin($email, $pass)
{
    if (empty($email) || empty($pass)) {
        return true;
    }
    return false;
}

function emptyInput($input)
{
    if (empty($input)) {
        return true;
    }
    return false;
}

function isValidDateFormat($date)
{
    return preg_match('/^\d{4}-\d{2}-\d{2}$/', $date);
}

function isValidTimeFormat($time)
{
    return preg_match('/^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/', $time);
}


function timeToMinutes($time)
{
    list($hours, $minutes) = explode(':', $time);
    return $hours * 60 + $minutes;
}

function isValidDateAndTime($nuo, $iki, $diena, $intervalas)
{
    if ($intervalas <= 0) {
        return false;
    }

    if (isValidTimeFormat($nuo) && isValidTimeFormat($iki) && isValidDateFormat($diena)) {
        $nuo_minutes = timeToMinutes($nuo);
        $iki_minutes = timeToMinutes($iki);

        if ($nuo_minutes < $iki_minutes) {
            return true;
        } else {
            return false;
        }
    } else {
        echo false;
    }
}

function invalidPass($pass)
{
    if (strlen($pass) > 7 && preg_match('/\d/', $pass) && preg_match("/[a-zA-Z]/", $pass) && !preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/', $pass)) {
        return false;
    }
    return true;
}

function invalidemail($email)
{
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return true;
    }
    return false;
}

function passMatch($pass, $passRepeat)
{
    if ($pass !== $passRepeat) {
        return true;
    }
    return false;
}

function emailExists($conn, $email)
{
    $sql = "SELECT * FROM naudotojai WHERE Elpastas = ?;";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: ../login.php?error=stmtfailed");
        exit();
    }

    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);

    $resultData = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($resultData)) {

        mysqli_stmt_close($stmt);
        return $row;

    }

    return false;
}

function invalidSpeciality($conn, $id)
{
    $sql = "SELECT * FROM specialybes WHERE Id = ?;";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: ../handledoctorregister.php?error=stmtfailed");
        exit();
    }

    mysqli_stmt_bind_param($stmt, "s", $id);
    mysqli_stmt_execute($stmt);

    $resultData = mysqli_stmt_get_result($stmt);

    if (mysqli_fetch_assoc($resultData)) {

        return false;

    }

    return true;
}

function specialityExists($conn, $name)
{
    $sql = "SELECT * FROM specialybes WHERE UPPER(Pavadinimas) = UPPER(?);";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: ../aaddspeciality.php?error=stmtfailed");
        exit();
    }

    mysqli_stmt_bind_param($stmt, "s", $name);
    mysqli_stmt_execute($stmt);

    $resultData = mysqli_stmt_get_result($stmt);

    if (mysqli_fetch_assoc($resultData)) {

        return true;

    }

    return false;
}

function UserExists($conn, $email, $pass)
{
    $resultData = emailExists($conn, $email);

    if ($resultData !== false) {
        $hashedPass = $resultData['Slaptazodis'];
        $passwordCheck = password_verify($pass, $hashedPass);
        if ($passwordCheck) {
            return $resultData;
        }
    }

    return false;
}

function createAccount($conn, $name, $surname, $email, $pass, $role, $speciality)
{
    if (emailExists($conn, $email) !== false) {
        header("location: ../register.php?error=userexists");
        exit();
    }

    $sql = "INSERT INTO naudotojai (`Vardas`, `Pavarde`, `Elpastas`, `Slaptazodis`, `RoleId`, `SpecialybeId`) VALUES(?, ?, ?, ?, ?, ?);";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        if ($role === 3) {
            header("location: ../register.php?error=stmtfailed");
        } else if ($role === 2) {
            header("location: ../aregisterdoctor.php?error=stmtfailed");
        }
        exit();
    }

    if ($role === 2 && invalidSpeciality($conn, $speciality)) {
        header("location: ../aregisterdoctor.php?error=invalidspeciality");
        exit();
    }

    $HashedPass = password_hash($pass, PASSWORD_DEFAULT);
    mysqli_stmt_bind_param($stmt, "ssssss", $name, $surname, $email, $HashedPass, $role, $speciality);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    if ($role === 3) {
        header("location: ../register.php?error=none");
    } else if ($role === 2) {
        header("location: ../aregisterdoctor.php?error=none");
    }
    exit();
}

function addSpeciality($conn, $name)
{
    if (specialityExists($conn, $name)) {
        header("location: ../aaddspeciality.php?error=specialityexists");
        exit();
    }

    $sql = "INSERT INTO specialybes (`Pavadinimas`) VALUES(?);";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: ../aaddspeciality.php?error=stmtfailed");
        exit();
    }

    mysqli_stmt_bind_param($stmt, "s", $name);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    header("location: ../aaddspeciality.php?error=none");

    exit();
}

function loginUser($conn, $email, $pass)
{
    $userExists = UserExists($conn, $email, $pass);
    if ($userExists === false) {
        header("location: ../login.php?error=wronglogin");
        exit();
    }

    session_start();
    $_SESSION['vardas'] = $userExists["Vardas"];
    $_SESSION['pavarde'] = $userExists["Pavarde"];
    $_SESSION['username'] = $email;
    $_SESSION['role'] = $userExists["RoleId"];
    $_SESSION['userid'] = $userExists["Id"];
    header("location: ../home.php");
    exit();
}

function getModelById($conn, $sql, $id)
{
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        return false;
    }

    mysqli_stmt_bind_param($stmt, "s", $id);
    mysqli_stmt_execute($stmt);

    $resultData = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($resultData)) {

        mysqli_stmt_close($stmt);
        return $row;

    }

    return false;
}

function getUser($conn, $id)
{
    $sql = "SELECT Id,
               Vardas,
               Pavarde,
               Elpastas,
               RoleId,
               SpecialybeId
            FROM naudotojai
            WHERE Id = ?;";

    return getModelById($conn, $sql, $id);
}

function getDoctor($conn, $id)
{
    $sql = "SELECT
                n.Id,
                Vardas,
                Pavarde,
                s.Pavadinimas as Specialybe
            FROM naudotojai n
            LEFT JOIN specialybes s ON n.SpecialybeId = s.Id
            WHERE n.Id = (?)";

    return getModelById($conn, $sql, $id);
}

function isDoctor($conn, $id)
{
    $user = getUser($conn, $id);

    if ($user !== false && $user["RoleId"] == 2) {
        return true;
    }

    return false;
}

function isOlder($checkDate)
{
    $now = date('Y-m-d H:i:s');

    $checkTimestamp = strtotime($checkDate);

    $nowTimestamp = strtotime($now);

    return ($checkTimestamp < $nowTimestamp);
}

function isUsedTimePeriod($conn, $id, $dateFrom, $dateTo)
{
    $sql = "SELECT Id, DataNuo, DataIki, NaudotojoId
FROM tvarkarasciai t
WHERE ((DataNuo < ? AND DataIki > ?) OR (DataNuo > ? AND DataIki < ?))
AND NaudotojoId = ?;";

    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        return false;
    }

    mysqli_stmt_bind_param($stmt, "sssss", $dateTo, $dateFrom, $dateFrom, $dateTo, $id);
    mysqli_stmt_execute($stmt);

    $resultData = mysqli_stmt_get_result($stmt);

    if (mysqli_fetch_assoc($resultData)) {

        mysqli_stmt_close($stmt);
        return true;

    }

    return false;
}

function checkAndGetVisitDd($conn, $tvarkarascioId)
{
    $sql = "select v.Id from vizitai v
join tvarkarasciai t on v.TvarkarascioId = t.Id
where v.TvarkarascioId = ?
  and t.NaudotojoId = ?
  and v.StatusasId = 1";

    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        return false;
    }

    mysqli_stmt_bind_param($stmt, "ss", $tvarkarascioId, $_SESSION['userid']);
    mysqli_stmt_execute($stmt);

    $resultData = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($resultData)) {

        mysqli_stmt_close($stmt);
        return $row["Id"];

    }

    return false;
}
function sendMessage($conn, $tvarkarascioId, $zinute)
{
    $vizitoId = checkAndGetVisitDd($conn, $tvarkarascioId);

    if ($vizitoId === false) {
        header("location: ../dtimetable.php?error=stmtfailed");
        exit();
    }

    $sql = "INSERT INTO zinutes (`Tekstas`, `Data`, `VizitoId`) VALUES(?, ?, ?);";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: ../dtimetable.php?error=stmtfailed");
        exit();
    }

    $date = date("Y-m-d H:i:s");

    mysqli_stmt_bind_param($stmt, "sss", $zinute, $date, $vizitoId);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("location: ../dtimetable.php?error=none");
    exit();
}

function addTime($conn, $id, $nuo, $iki, $diena, $intervalas)
{
    $dateFrom = $diena . " " . $nuo;
    $dateTo = $diena . " " . $iki;

    if (isOlder($dateFrom)) {
        header("location: ../atimetable.php?id=" . $id . "&error=oldtime");
        exit();
    }

    if (!isDoctor($conn, $id)) {
        header("location: ../atimetable.php?id=" . $id . "&error=wrongid");
        exit();
    }

    if (isUsedTimePeriod($conn, $id, $dateFrom, $dateTo)) {
        header("location: ../atimetable.php?id=" . $id . "&error=usedtime");
        exit();
    }

    // Calculate time intervals
    $startTime = strtotime($dateFrom);
    $endTime = strtotime($dateTo);
    $interval = $intervalas * 60; // Convert minutes to seconds

    while ($startTime < $endTime) {
        $nextTime = $startTime + $interval;

        if ($nextTime > $endTime) {
            $nextTime = $endTime;
        }

        $nextDateTime = date("Y-m-d H:i:s", $nextTime);

        $sql = "INSERT INTO tvarkarasciai (`NaudotojoId`, `DataNuo`, `DataIki`) VALUES(?, ?, ?);";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
            header("location: ../atimetable.php?id=" . $id . "&error=stmtfailed");
            exit();
        }

        $date = date("Y-m-d H:i:s", $startTime);
        mysqli_stmt_bind_param($stmt, "sss", $id, $date, $nextDateTime);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        $startTime = $nextTime;
    }

    header("location: ../atimetable.php?id=" . $id . "&error=none");
    exit();
}

function canReserveVisit($conn, $tvarkarascioId, $naudotojoId)
{
    $sql = "with bannedDates as (select tv.DataNuo, tv.DataIki from vizitai v
join tvarkarasciai tv on v.TvarkarascioId = tv.Id
where v.NaudotojoId = ?
and v.StatusasId = 1)

select * from tvarkarasciai t
left join bannedDates bd
on ((t.DataNuo < bd.DataIki AND t.DataIki > bd.DataNuo) OR (t.DataNuo > bd.DataNuo AND t.DataIki < bd.DataIki))

where NOW() < t.DataNuo

and t.Id not in (select v.TvarkarascioId from vizitai v where v.StatusasId = 1)
and t.Id = ?
and bd.DataIki is null";

    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        return false;
    }

    mysqli_stmt_bind_param($stmt, "ss", $naudotojoId, $tvarkarascioId);
    mysqli_stmt_execute($stmt);

    $resultData = mysqli_stmt_get_result($stmt);

    if (mysqli_fetch_assoc($resultData)) {

        mysqli_stmt_close($stmt);
        return true;

    }

    return false;
}

function approveReservation($conn, $id, $doctorId)
{
    $sql = "INSERT INTO vizitai (`StatusasId`, `NaudotojoId`, `TvarkarascioId`) VALUES(?, ?, ?);";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: ../ptimetable.php?id=" . $doctorId . "&error=stmtfailed");
        exit();
    }

    $status = '1';

    mysqli_stmt_bind_param($stmt, "sss", $status, $_SESSION['userid'], $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    header("location: ../ptimetable.php?id=" . $doctorId . "&error=none");
    exit();
}

function cancelVisit($conn, $id)
{
    $sql = "UPDATE vizitai SET StatusasId = 2 WHERE Id = ? and NaudotojoId = ?;";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: ../pvisithistory.php?error=stmtfailed");
        exit();
    }

    $status = '1';

    mysqli_stmt_bind_param($stmt, "ss", $id, $_SESSION['userid']);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    header("location: ../pvisithistory.php?error=none");
    exit();
}