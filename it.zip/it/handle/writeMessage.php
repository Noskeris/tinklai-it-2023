<?php
global $conn;
session_start();
if (!isset($_SESSION['role'])) {
    header("Location: logout.php");
    exit;
}
if ($_SESSION['role'] != 2) {
    header("Location: ../home.php");
    exit;
}
require_once 'config.php';
require_once 'functions.php';
$id = $_POST["id"];
if (isset($_POST["sendmessage"])) {
    $zinute = $_POST["message"];

    if (emptyInput($zinute)) {
        header("location: ../dtimetable.php?error=empty");
        exit();
    }

    sendMessage($conn, $id, $zinute);

    exit();
} else {
    header("location: ../dtimetable.php");
}
