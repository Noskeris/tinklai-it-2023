<?php

global $conn;
if (isset($_POST["login"])) {
    $email = $_POST["email"];
    $pass = $_POST["pass"];
    require_once 'config.php';
    require_once 'functions.php';

    if (emptyInputsLogin($email, $pass) !== false) {
        header("location: ../login.php?error=empty");
        exit();
    }
    loginUser($conn, $email, $pass);
} else {
    header("location: ../login.php");
    exit();
}

?>