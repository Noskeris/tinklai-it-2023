<?php

global $conn;
if (isset($_POST["register"])) {
    $name = $_POST["name"];
    $surname = $_POST["surname"];
    $email = $_POST["email"];
    $pass = $_POST["pass"];
    $passRepeat = $_POST["passRepeat"];
    require_once 'config.php';
    require_once 'functions.php';

    if (emptyInputsRegister($name, $surname, $email, $pass, $passRepeat) !== false) {
        header("location: ../register.php?error=empty");
        exit();
    }
    if (invalidemail($email) !== false) {
        header("location: ../register.php?error=invalidemail");
        exit();
    }
    if (passMatch($pass, $passRepeat) !== false) {
        header("location: ../register.php?error=passwordsdoesntmatch");
        exit();
    }
    if (invalidPass($pass) !== false) {
        header("location: ../register.php?error=invalidpassword");
        exit();
    }
    createAccount($conn, $name, $surname, $email, $pass, 3, null);
    exit();
} else {
    header("location: ../register.php");
}

