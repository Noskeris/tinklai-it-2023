<?php
define('HOSTNAME', 'localhost');
define('USERNAME', 'stud');
define('PASSWORD', 'stud');
define('DATABASE', 'prs');

$user_roles = array(
    "Administratorius" => "1",
    "Gydytojas" => "2",
    "Pacientas" => "3"
);

$conn = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DATABASE);
mysqli_set_charset($conn, "utf8");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

