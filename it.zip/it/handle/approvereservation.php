<?php
global $conn;
session_start();
if (!isset($_SESSION['role'])) {
    header("Location: logout.php");
    exit;
}
if ($_SESSION['role'] != 3) {
    header("Location: ../home.php");
    exit;
}
$doctorId = $_POST["doctorId"];

require_once 'config.php';
require_once 'functions.php';

if (isset($_POST["approveReservation"])) {
    $tvarkarascioId = $_POST["id"];
    $doctorId = $_POST["doctorId"];

    if (emptyInput($tvarkarascioId)) {
        header("location: ../ptimetable.php?id=" . $doctorId . "&error=empty");
        exit();
    }

    approveReservation($conn, $tvarkarascioId, $doctorId);
    exit();
} else {
    header("location: ../ptimetable.php?id=" . $doctorId);
}

