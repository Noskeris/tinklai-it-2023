<?php
global $conn;
include_once 'sidenav.php';
if (!isset($_SESSION['role'])) {
    header("Location: handle/logout.php");
    exit;
}
if ($_SESSION['role'] != 3) {
    header("Location: home.php");
    exit;
}

$id = $_SESSION["userid"];

require_once("handle/config.php");
$sql = "SELECT
            v.Id as Id,
            if(now() > DataIki and s.Id != 2, 'Pasibaigęs', s.Pavadinimas) as Statusas,
            DATE(DataNuo) AS Data,
            CONCAT(DATE_FORMAT(DataNuo, '%H:%i'), '-', DATE_FORMAT(DataIki, '%H:%i')) AS Laikas,
            g.Vardas,
            g.Pavarde,
            g.Specialybe
        from vizitai v
        join statusai s
            on v.StatusasId = s.Id
        join tvarkarasciai t
            on v.TvarkarascioId = t.Id
        join (
           select
               n.Id,
               n.Vardas,
               n.Pavarde,
               s2.Pavadinimas as Specialybe
           from naudotojai n
           join specialybes s2
               on n.SpecialybeId = s2.Id
        ) g
            on g.Id = t.NaudotojoId
        where v.NaudotojoId = ?
        order by t.DataNuo desc, s.Id";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt, $sql)) {
    return false;
}

mysqli_stmt_bind_param($stmt, "s", $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

?>

<div class="content ">
    <h1 class="text-success d-flex justify-content-center">Mano vizitų istorija</h1>
    <p class="d-flex justify-content-center">Čia rasite visą savo vizitų istoriją, įskaitant ir būsimus vizitus</p>

    <div class="modal fade" id="cancelVisitModal" tabindex="-1" aria-labelledby="cancelVisitModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="cancelVisitModalLabel">Ar tikrai norite atšaukti vizitą?</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <form action="handle/cancelVisit.php" method="post">
                    <div class="form-group">
                        <input type="hidden" id="idInput" name="id">
                    </div>
                    <div class="modal-footer" style="padding: 10px">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Atsisakyti</button>
                        <button type="submit" name="cancelVisit" class="btn btn-danger">Atšaukti</button>
                    </div>


                </form>
            </div>
        </div>
    </div>

    <table class="table">
        <thead>
        <tr>
            <th>Gydytojo vardas ir pavardė</th>
            <th>Gydytojo specialybė</th>
            <th>Vizito statusas</th>
            <th>Data</th>
            <th>Laikas</th>
            <th>Veiksmas</th>
        </tr>
        </thead>
        <tbody>
        <?php
        if (mysqli_num_rows($result) === 0) {
            echo "<tr><td colspan='7' style='text-align: center;'>Neturite jokių vizitų</td></tr>";
        } else {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row['Vardas'] . " " . $row['Pavarde'] . "</td>";
                echo "<td>" . $row['Specialybe'] . "</td>";
                echo "<td>" . $row['Statusas'] . "</td>";
                echo "<td>" . $row['Data'] . "</td>";
                echo "<td>" . $row['Laikas'] . "</td>";
                if ($row['Statusas'] == "Rezervuota") {
                    echo "<td><button type='button' class='btn btn-danger clickable-cell' data-id='" . $row['Id'] . "' data-bs-toggle='modal' data-bs-target='#cancelVisitModal'>
        Atšaukti
    </button></td>";
                } else {
                    echo "<td></td>";
                }
                echo "</tr>";
            }
        }
        ?>
        </tbody>
    </table>
</div>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const cell = document.querySelector(".clickable-cell");

        cell.addEventListener("click", function () {
            const id = cell.getAttribute("data-id");
            openModalWithId(id);
        });

        function openModalWithId(id) {
            // Set the ID value in the hidden input field in the modal form
            const modalForm = document.querySelector("#cancelVisitModal form");
            const idInput = modalForm.querySelector("[name='id']");
            idInput.value = id;
        }
    });
</script>