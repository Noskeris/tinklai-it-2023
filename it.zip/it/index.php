<?php
include_once 'sidenav.php';
if (isset($_SESSION['role'])) {

    header("Location: home.php");
    exit;
}
?>
<div class="content">
    <h1 class="text-success">Pacientų registracijos sistema</h1>
    <p>Sistema gali naudotis tik registruoti naudotojai</p>
    <p>Autorius: Nojus Bronušas</p>
    <div>
        <a class="btn btn-secondary btn-lg" href="register.php">Registruotis</a>
        <a class="btn btn-success btn-lg" href="login.php">Prisijungti</a>
    </div>
</div>