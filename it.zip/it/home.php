<?php
global $conn;
include_once 'sidenav.php';
require_once("handle/config.php");
require_once("handle/functions.php");

if (!isset($_SESSION['role'])) {
    header("Location: handle/logout.php");
    exit;
}
$user = $_SESSION['username'];
$userlevel = $_SESSION['role'];
$role = "";
foreach ($user_roles as $x => $x_value) {
    if ($x_value == $userlevel) $role = $x;
}
?>

<div class="content">
    <?php
    if ($role == "Administratorius") {
        include_once 'admin.php';
    } else if ($role == "Gydytojas") {
        include_once 'doctor.php';
    } else {
        include_once 'patient.php';
    }

    mysqli_close($conn);
    ?>
</div>