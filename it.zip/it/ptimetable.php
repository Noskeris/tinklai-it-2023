<?php
global $conn;
include_once 'sidenav.php';
if (!isset($_SESSION['role'])) {
    header("Location: handle/logout.php");
    exit;
}
if ($_SESSION['role'] != 3) {
    header("Location: home.php");
    exit;
}

$id = -1;

require_once 'handle/config.php';
require_once 'handle/functions.php';

if (isset($_GET["id"])) {
    $temp = $_GET["id"];

    if (isDoctor($conn, $temp)) {
        $id = $temp;
    }
}

if ($id == -1) {
    header("Location: home.php");
    exit;
}

$doctor = getDoctor($conn, $id);

$sql = "SELECT
    tm.Id,
    DATE(DataNuo) AS Data,
    CONCAT(DATE_FORMAT(DataNuo, '%H:%i'), '-', DATE_FORMAT(DataIki, '%H:%i')) AS Laikas,
    IF(NOW() BETWEEN DataNuo AND DataIki, 1, 0) AS ArDabar,
    IFNULL(c.VizituSkaicius, 0) AS VizituSkaicius
FROM tvarkarasciai tm
LEFT JOIN (
    SELECT
        NaudotojoId,
        DATE(DataNuo) AS Data,
        COUNT(*) AS VizituSkaicius
    FROM (
        SELECT
            NaudotojoId,
            DataNuo
        FROM tvarkarasciai
        WHERE DataIki > NOW()
            AND Id NOT IN (SELECT TvarkarascioId FROM vizitai WHERE StatusasId = 1)
    ) t
    GROUP BY NaudotojoId, DATE(DataNuo)
) c ON tm.NaudotojoId = c.NaudotojoId AND DATE(tm.DataNuo) = c.Data
WHERE tm.NaudotojoId = ?
    AND DataIki > NOW()
    AND tm.Id NOT IN (SELECT TvarkarascioId FROM vizitai WHERE StatusasId = 1)
ORDER BY DATE(DataNuo) DESC, TIME(DataNuo);";

$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt, $sql)) {
    return false;
}

mysqli_stmt_bind_param($stmt, "s", $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

?>

<html lang="lt">
<head>
    <style>
        .clickable-row:hover {
            background-color: #f2f2f2;
            cursor: pointer;
        }

        .clicked-row {
            background-color: #e0e0e0;
        }
    </style>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


</head>

<body>
<div class="content">
    <h1 class="text-success d-flex justify-content-center">Gydytojo profilis</h1>
    <p class="d-flex justify-content-center">Jei norite užsiregistruoti pas gydytoją, spauskite ant norimo laiko ir mygtuką patvirtinti</p>

    <?php

    echo "<b><p class='d-flex justify-content-center'>" . "Gyd. " .
        $doctor['Vardas'] . " " . $doctor['Pavarde'] .
        " - " . $doctor['Specialybe'] .
        "</p></b>";

    ?>


    <div class="modal fade" id="approveReservationModal" tabindex="-1" aria-labelledby="approveReservationModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="approveReservationModalLabel">Ar tikrai norite patvirtinti
                        rezervaciją?</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <form action="handle/approvereservation.php" method="post">
                <div class="form-group">
                    <input type="hidden" id="idInput" name="id">
                    <input type="hidden" name="doctorId" value="<?php echo $id; ?>">
                </div>
                    <div class="modal-footer" style="padding: 10px">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Atšaukti</button>
                        <button type="submit" name="approveReservation" class="btn btn-success">Patvirtinti</button>
                    </div>


                </form>
            </div>
        </div>
    </div>


    <div style="display: flex; justify-content: space-between; align-items: center;">
        <h4>Laisvi laikai pas gydytoją</h4>
    </div>

    <?php
    if (isset($_GET["error"])) {
        echo "<b class='text-danger'>";
        if ($_GET["error"] == "stmtfailed") {
            echo "Klaida: bandykite dar kartą";
        }
        if ($_GET["error"] == "empty") {
            echo "Klaida: Nevisi laukai yra užpildyti";
        }
        if ($_GET["error"] == "alreadyreserved") {
            echo "Klaida: Jau esate užsiregistravęs pas kitą gydytoją tokiu pačiu laiku";
        }

        echo "</b>";

        if ($_GET["error"] == "none") {
            echo "<b class='text-success'>Sėkmingai užsiregistravote. Peržiūrėti vizitus galite vizitų istorijoje</b>";
        }
    }
    ?>
    
    <table class="table">
        <thead>
        <tr>
            <th style='text-align: center;'>Data</th>
            <th style='text-align: center;'>Laikas</th>
        </tr>
        </thead>
        <tbody>
        <?php
        if (mysqli_num_rows($result) === 0) {
            echo "<tr><td colspan='2' style='text-align: center;'>Šiuo metu gydytojas neturi sudaryto tvarkaraščio</td></tr>";
        } else {
            $day = "";

            while ($row = mysqli_fetch_assoc($result)) {
                $backgroundcolor = '';
                if ($row["ArDabar"]) {
                    $backgroundcolor = 'font-weight: bold; color: green;';
                }
                if ($day !== $row["Data"]) {
                    $day = $row["Data"];
                    echo "<td rowspan='" . $row["VizituSkaicius"] . "' style='text-align: center;" . $backgroundcolor . "'>" . $row['Data'] . "</td>";
                }
                echo "<td class='clickable-cell' data-id='" . $row['Id'] . "'style='text-align: center;" . $backgroundcolor . "'>" . $row['Laikas'] . "</td>";
                echo "</tr>";
            }
        }
        ?>
        </tbody>
    </table>
</div>

<style>
    .clickable-cell:hover {
        background-color: #f2f2f2;
        cursor: pointer;
    }

    .clicked-cell {
        background-color: #e0e0e0;
    }
</style>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const cells = document.querySelectorAll(".clickable-cell");

        cells.forEach(function(cell) {
            cell.addEventListener("click", function () {
                const id = cell.getAttribute("data-id");
                openModalWithId(id);
            });
        });

        function openModalWithId(id) {
            const modalForm = document.querySelector("#approveReservationModal form");
            const idInput = modalForm.querySelector("[name='id']");
            idInput.value = id;

            const modal = new bootstrap.Modal(document.getElementById("approveReservationModal"));
            modal.show();
        }
    });
</script>

</body>
</html>