<?php
global $conn;
include_once 'sidenav.php';
if (!isset($_SESSION['role'])) {
    header("Location: handle/logout.php");
    exit;
}
if ($_SESSION['role'] != 1) {
    header("Location: home.php");
    exit;
}

$id = -1;

require_once 'handle/config.php';
require_once 'handle/functions.php';

if (isset($_GET["id"])) {
    $temp = $_GET["id"];

    if (isDoctor($conn, $temp)) {
        $id = $temp;
    }
}

if ($id == -1) {
    header("Location: home.php");
    exit;
}

$doctor = getDoctor($conn, $id);

$sql = "select
    DATE(DataNuo) AS Data,
    CONCAT(DATE_FORMAT(DataNuo, '%H:%i'), '-', DATE_FORMAT(DataIki, '%H:%i')) AS Laikas,
    IF(NOW() BETWEEN DataNuo AND DataIki, 1, 0) AS ArDabar,
    c.VizituSkaicius
from tvarkarasciai tm

left join (
    select *, count(*) as VizituSkaicius from (select
        NaudotojoId,
        DATE(DataNuo) as Data
    from tvarkarasciai) t
    group by NaudotojoId, DATE(Data)
) c on tm.NaudotojoId = c.NaudotojoId and DATE(tm.DataNuo) = DATE(c.Data)

where tm.NaudotojoId = ?
order by DATE(DataNuo) desc, TIME(DataNuo) DESC";

$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt, $sql)) {
    return false;
}

mysqli_stmt_bind_param($stmt, "s", $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

?>

<html lang="lt">
<head>
    <style>
        .clickable-row:hover {
            background-color: #f2f2f2;
            cursor: pointer;
        }

        .clicked-row {
            background-color: #e0e0e0;
        }
    </style>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


</head>

<body>
<div class="content">
    <h1 class="text-success d-flex justify-content-center">Gydytojo profilis</h1>
    <p class="d-flex justify-content-center">Jei norite pridėti papildomą laiką į tvarkaraštį, spauskite
        mygtuką "Pridėti naują laiką"</p>

    <?php

    echo "<b><p class='d-flex justify-content-center'>" . "Gyd. " .
        $doctor['Vardas'] . " " . $doctor['Pavarde'] .
        " - " . $doctor['Specialybe'] .
        "</p></b>";

    ?>

    <div style="display: flex; justify-content: space-between; align-items: center;">
        <h4>Gydytojo tvarkaraštis</h4>
        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addTimeModal">
            Pridėti naujus laikus
        </button>
    </div>

    <?php
    if (isset($_GET["error"])) {
        echo "<b class='text-danger'>";
        if ($_GET["error"] == "stmtfailed") {
            echo "Klaida: bandykite dar kartą";
        }
        if ($_GET["error"] == "empty") {
            echo "Klaida: Nevisi laukai yra užpildyti";
        }
        if ($_GET["error"] == "baddateortime") {
            echo "Klaida: Neteisingas datos formatas arba intervalai";
        }
        if ($_GET["error"] == "oldtime") {
            echo "Klaida: Laiko periodas negali būti ankstesnis nei dabarties laikas";
        }
        if ($_GET["error"] == "wrongid") {
            echo "Klaida: Neteisingas ID";
        }
        if ($_GET["error"] == "usedtime") {
            echo "Klaida: Tuo pačiu laiku, gydytojas gali turėti tik vieną vizitą";
        }

        echo "</b>";

        if ($_GET["error"] == "none") {
            echo "<b class='text-success'>Nauji laikai buvo pridėti sėkmingai</b>";
        }
    }
    ?>


    <div class="modal fade" id="addTimeModal" tabindex="-1" aria-labelledby="addTimeModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="addTimeModalLabel">Pridėti naujus laikus</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <form action="handle/addtime.php" method="POST" onsubmit="return validateForm()">
                    <div class="modal-body">
                        <div class="form-group">
                            <input type="hidden" name="id" value="<?php echo $id; ?>">
                            <label for="dateInput">Data</label>
                            <input class="form-control" type="text" id="dateInput" name="diena" required
                                   placeholder="yyyy-mm-dd">
                            <div id="dateWarning" style="color: red;"></div>
                        </div>

                        <div class="form-group">
                            <label for="timeInput1">Laikas nuo</label>
                            <input class="form-control" type="text" id="timeInput1" name="nuo" required
                                   placeholder="hh:mm">
                            <div id="time1Warning" style="color: red;"></div>
                        </div>

                        <div class="form-group">
                            <label for="timeInput2">Laikas iki</label>
                            <input class="form-control" type="text" id="timeInput2" name="iki" required
                                   placeholder="hh:mm">
                            <div id="time2Warning" style="color: red;"></div>
                        </div>

                        <div class="form-group">
                            <label for="timeInterval">Vizito trukmė (minutėmis)</label>
                            <input class="form-control" type="text" id="timeInterval" name="intervalas" required
                                   placeholder="15">
                            <div id="timeIntervalWarning" style="color: red;"></div>
                        </div>


                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Atšaukti</button>
                        <button type="submit" name="addtime" class="btn btn-success">Pridėti</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <table class="table">
        <thead>
        <tr>
            <th style='text-align: center;'>Data</th>
            <th style='text-align: center;'>Laikas</th>
        </tr>
        </thead>
        <tbody>
        <?php
        if (mysqli_num_rows($result) === 0) {
            echo "<tr><td colspan='2' style='text-align: center;'>Šiuo metu gydytojas neturi sudaryto tvarkaraščio</td></tr>";
        } else {
            $day = "";
            while ($row = mysqli_fetch_assoc($result)) {
                $backgroundcolor = '';
                if ($row["ArDabar"]) {
                    $backgroundcolor = 'font-weight: bold; color: green;';
                }
                if ($day !== $row["Data"]) {
                    $day = $row["Data"];
                    echo "<td rowspan='" . $row["VizituSkaicius"] . "' style='text-align: center;" . $backgroundcolor . "'>" . $row['Data'] . "</td>";
                }
                echo "<td style='text-align: center;" . $backgroundcolor . "'>" . $row['Laikas'] . "</td>";
                echo "</tr>";
            }
        }
        ?>
        </tbody>
    </table>
</div>
<script>
    function validateDate(inputValue) {
        const datePattern = /^\d{4}-\d{2}-\d{2}$/;
        const isValidFormat = datePattern.test(inputValue);

        if (!isValidFormat) {
            return false;
        }

        // Check if the entered date is a valid date using the Date object.
        const [year, month, day] = inputValue.split('-');
        const dateObject = new Date(year, month - 1, day); // Note: Months are 0-based in JavaScript.

        return (
            dateObject.getFullYear() == year &&
            dateObject.getMonth() == month - 1 &&
            dateObject.getDate() == day
        );
    }

    function validateTimeInput(inputValue, warningId) {
        const timePattern = /^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/;
        const isValidFormat = timePattern.test(inputValue);

        const warningElement = document.getElementById(warningId);

        if (!isValidFormat) {
            warningElement.textContent = 'Neteisingas formatas. Naudokite hh:mm.';
            return false;
        } else {
            warningElement.textContent = ''; // Clear the warning.
            return true;
        }
    }

    function validateTimeInterval(interval, warningId) {
        const parsedInterval = parseInt(interval);
        if (!Number.isInteger(parsedInterval) || parsedInterval <= 0) {
            // If the interval is not a positive integer, display a warning
            document.getElementById(warningId).innerText = 'Please enter a valid positive integer for the time interval';
            return false;
        }
        return true;
    }

    function validateForm() {
        const dateValue = document.getElementById('dateInput').value;
        const time1Value = document.getElementById('timeInput1').value;
        const time2Value = document.getElementById('timeInput2').value;
        const timeInterval = document.getElementById('timeInterval').value;

        const isDateValid = validateDate(dateValue);
        const isTime1Valid = validateTimeInput(time1Value, 'time1Warning');
        const isTime2Valid = validateTimeInput(time2Value, 'time2Warning');
        const timeIntervalValid = validateTimeInput(time2Value, 'timeIntervalWarning');

        const [hours1, minutes1] = time1Value.split(':').map(Number);
        const [hours2, minutes2] = time2Value.split(':').map(Number);

        if (!timeIntervalValid) {
            document.getElementById('timeIntervalWarning').textContent = 'Reikia teigiamo sveiko skaičius';
        } else {
            document.getElementById('timeIntervalWarning').textContent = '';
        }

        if (hours1 > hours2 || (hours1 === hours2 && minutes1 >= minutes2)) {
            document.getElementById('time1Warning').textContent = 'Laikas nuo turi būti mažesnis nei laikas iki.';
            return false;
        }

        if (!isDateValid) {
            document.getElementById('dateWarning').textContent = 'Neteisingas formatas';
        } else {
            document.getElementById('dateWarning').textContent = '';
        }

        return isDateValid && isTime1Valid && isTime2Valid;
    }
</script>
</body>
</html>